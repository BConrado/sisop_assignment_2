Bruno Conrado & Lucas Salbego

Utilizando o particionamento fixo, nós representamos toda memória livre separada em partições, inclusive a fragmentação dentro da memória contigua,

Para compilar utilize 

	javac *.java

Para rodar utilize o comando 

	java App.java <<nomeDoArquivo.txt>>

Pode utilizar os arquivos existentes na pasta

As opcoes de metodos e politicas sao escolhidas durante a execucao